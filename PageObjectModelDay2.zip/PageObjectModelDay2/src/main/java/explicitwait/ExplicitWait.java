package explicitwait;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ExplicitWait extends BaseClass {

	public ChromeDriver driver;

	public ExplicitWait(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBys({ @FindBy(how = How.ID, using = "btn"), @FindBy(how = How.XPATH, using = "//button") })
	WebElement disppearElement;

	public void test() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.invisibilityOf(disppearElement));
		boolean displayed = disppearElement.isDisplayed();
		System.out.println(displayed);
		Assert.assertFalse(displayed);
	}
}
