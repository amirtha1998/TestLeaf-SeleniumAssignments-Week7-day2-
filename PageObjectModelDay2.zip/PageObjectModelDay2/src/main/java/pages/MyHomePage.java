package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class MyHomePage extends ProjectSpecificationMethods{
	
	public MyHomePage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public MyLeads clickOnLeads() {
		driver.findElement(By.linkText(prop1.getProperty("link_leads"))).click();
		return new MyLeads(driver);

	}
	
	public ContactPage clickOnContact() {
		driver.findElement(By.linkText("Contacts")).click();
		return new ContactPage(driver);

	}
}
