package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class FindLeads extends ProjectSpecificationMethods {

	public FindLeads(ChromeDriver driver) {
		this.driver = driver;
	}

	

	public FindLeads clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return new FindLeads(driver);

	}

	public FindLeads typePhone(String ph) {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(ph);
		return new FindLeads(driver);
	}

	public FindLeads clickFind() throws InterruptedException {
		driver.findElement(By.linkText(prop1.getProperty("find_leads"))).click();
		Thread.sleep(2000);
		return new FindLeads(driver);
	}

	public EditPage clickFirstElement() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new EditPage(driver);
	}
	
	public DeletePage clickOnFirstElement() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new DeletePage(driver);
	}

}
