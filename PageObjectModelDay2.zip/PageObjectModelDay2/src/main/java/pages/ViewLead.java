package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificationMethods;

public class ViewLead extends ProjectSpecificationMethods{
	
	public ViewLead(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public void verifyTitle() {
		String title = driver.getTitle();
		Assert.assertEquals(prop1.getProperty("exptitle"), title);
	}

	public void verifyFirstname(String fName) {
		String text = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(text, fName);
	}
	public LoginPage clickLogout() {
		driver.findElement(By.linkText(prop1.getProperty("logout")));
		return new LoginPage(driver);
		
	}
	
	public DuplicatePage clickDuplicate() {
		driver.findElement(By.linkText(prop1.getProperty("duplicate_lead"))).click();
		return new DuplicatePage(driver);
	}
	
	String exTitle = "D�tails du prospect | opentaps CRM";
	public void title() {
		String title = driver.getTitle();
		Assert.assertEquals(exTitle, title);
	}
}
