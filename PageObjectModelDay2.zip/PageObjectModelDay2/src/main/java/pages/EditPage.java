package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class EditPage extends ProjectSpecificationMethods{
	
	public EditPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EditLead clickOnEdit() {
	driver.findElement(By.linkText(prop1.getProperty("modify"))).click();
	return new EditLead(driver);
	}
}
