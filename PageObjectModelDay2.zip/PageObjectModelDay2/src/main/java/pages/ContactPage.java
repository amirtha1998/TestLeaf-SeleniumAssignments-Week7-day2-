package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class ContactPage extends ProjectSpecificationMethods{

	public ContactPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public CreateContactPage clickOnCreateContact() {
	driver.findElement(By.linkText(prop1.getProperty("link_create_contact"))).click();
	return new CreateContactPage(driver);

	}
}
