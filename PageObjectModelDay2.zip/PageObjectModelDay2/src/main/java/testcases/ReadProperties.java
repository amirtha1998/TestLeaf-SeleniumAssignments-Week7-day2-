package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadProperties {

	Properties prop = new Properties();
	
	//FileInputStream fis = new FileInputStream(new File("./src/main/resources/application.properties"));
	
	//prop.load(fis);
	
}
