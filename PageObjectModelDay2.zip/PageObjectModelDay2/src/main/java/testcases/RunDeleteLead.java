package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificationMethods;
import pages.LoginPage;

public class RunDeleteLead extends ProjectSpecificationMethods{
	@BeforeTest
	public void setUp() {
		fileName = "DeleteLead";
	}

	@Test(dataProvider = "getData")
	public void runDelete(String ph) {
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickOnLeads()
		.clickFindLead()
		.clickPhone()
		.typePhone(ph)
		.clickOnFirstElement()
		.clickDelete()
		.verifyDelete();
		
	}
		
}
