package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificationMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificationMethods{
	@Test
	public void clickLogin() {
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername().enterPassword().clickLoginButton();
		//.clickLogoutButton();
	}
}
