package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificationMethods;
import pages.LoginPage;

public class RunCreateContact extends ProjectSpecificationMethods{

	@BeforeTest
	public void setUp() {
		fileName = "CreateContact";
	}

	@Test(dataProvider = "getData")
	public void runCreate(String firstName,String lastName, String department, String description) {
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickOnContact()
		.clickOnCreateContact()
		.typeFirstName(firstName)
		.typeLastName(lastName)
		.typeDepartmentName(department)
		.typeDescription(description)
		.submitButton()
		.verifytheTitle();
	}
}
